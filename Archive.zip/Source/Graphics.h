
#pragma once
#include "InteractionLogic.h"

class SpinnerGraphics : public juce::Component, public Interaction
{
public:
    SpinnerGraphics();
    void paint(juce::Graphics& g) override;
    
    void drawWheel(juce::Graphics& g, int index, int x, int y, int width, int height);
    void drawSummedWheel(juce::Graphics& g, int x, int y, int width, int height);
    void drawThreshold(juce::Graphics& g, int x, int y, int width, int height);
    juce::Path wheelPath(juce::Graphics& g, int index, int x, int y, int width, int height);
    
    void drawDoubleOverlap(juce::Graphics& g, juce::Path& pathA, juce::Path& pathB, juce::Colour color);
    void drawTripleOverlap(juce::Graphics& g, juce::Path& pathA, juce::Path& pathB, juce::Path& pathC, juce::Colour color);
    
    void setAnimation(float value)
    {
        animationValue = value;
        isometricSkew = (1.0f - animationValue) + 1.0f;
    }
    
    
    void sumAngles();
    void resized() override {}
    
    void setParams(int index, float phaseValue, int divisionValue, bool stateValue, float opacityValue);
//    void setNumThresholds(std::array<float, 16> heldNotes);


private:
    float animationValue;
    float isometricSkew;
    float yOffset, yPosOffset;
    
    juce::Colour color0 = { 255, 0, 0 };
    juce::Colour color1 = { 0, 0, 255 };
    juce::Colour color2 = { 0, 255, 0 };
};


class DialGraphics : public juce::LookAndFeel_V4
{
public:
    DialGraphics(int index)
    {
        this->index = index;
    }
    
    void drawRotarySlider(juce::Graphics &g, int x, int y, int width, int height, float sliderPosProportional, float rotaryStartAngle, float rotaryEndAngle, juce::Slider &slider) override
    {
        auto bounds = slider.getLocalBounds().toFloat();
        float xPos = bounds.getX();
        float yPos = bounds.getY();
        float size = bounds.getWidth();
        
        switch(index)
        {
            case 0:
                drawRateSlider(g, xPos, yPos, size, sliderPosProportional);
                break;
            case 1:
                drawDivisionSlider(g, xPos, yPos, size, sliderPosProportional);
                break;
            case 2:
                drawRoundDial(g, xPos, yPos, size, sliderPosProportional);
                break;
            case 3:
                
                break;
        }
    }
    
    void drawRateSlider(juce::Graphics &g, float x, float y, float size, float position)
    {
        float width = size * 0.8f;
        float widthMargin = size * 0.1f;
        float posScaled = std::abs(position - 0.5f);
        float needleWidth = width * 0.05f + (width * 0.35f * posScaled);

        
        float height = size * 0.5f;
        float heightMargin = size * 0.25f;
        float baseHeight = height * 0.1f;
        float needleHeight = height * 0.9f;
        
        juce::Point<float> topLeftCoords = { x + widthMargin, y + heightMargin + height - baseHeight };
        juce::Point<float> botLeftCoords = { x + widthMargin, y + heightMargin + height };
        juce::Point<float> topRightCoords = { x + widthMargin + width, y + heightMargin + height - baseHeight };
        juce::Point<float> botRightCoords = { x + widthMargin + width, y + heightMargin + height };

        float needlePos = (needleWidth/2) + width * 0.6f * position;
        juce::Point<float> midCoords = { x + widthMargin + needlePos, y + heightMargin };
        juce::Point<float> midLeftCoords = { midCoords.x - needleWidth/2, topLeftCoords.y};
        juce::Point<float> midRightCoords =  { midCoords.x + needleWidth/2, topRightCoords.y};
        
        juce::Path graphicPath;
        graphicPath.startNewSubPath(topLeftCoords);
        graphicPath.lineTo(midLeftCoords);
        graphicPath.lineTo(midCoords);
        graphicPath.lineTo(midRightCoords);
        graphicPath.lineTo(topRightCoords);
        graphicPath = graphicPath.createPathWithRoundedCorners(10);

        graphicPath.startNewSubPath(botRightCoords);
        graphicPath.lineTo(botLeftCoords);

        g.setColour(juce::Colour(50, 50, 50));
        g.strokePath(graphicPath, juce::PathStrokeType(2.0f));

    }
    
    void drawDivisionSlider(juce::Graphics &g, float x, float y, float size, float position)
    {
        float sliderPos = position * 5.0f;
        sliderPos = std::floor(sliderPos) + 1;
        
        float radius = size * 0.35f;
        float twopi = juce::MathConstants<float>::twoPi;
                
        float segmentSize = twopi/sliderPos;
        float phaseOffset = position * twopi;
        
        for(int i = 0; i < sliderPos; i += 2)
        {
            
            if (i % 2 == 0) {
                float startAngle = phaseOffset + i * segmentSize;
                float endAngle = phaseOffset + (i + 1) * segmentSize;

            juce::Path graphicPath;
                float heightOffset = 0; //i * 2;
                graphicPath.startNewSubPath(x + size/2, (y + size/2) + heightOffset);
                graphicPath.addCentredArc(x + size/2, (y + size/2) + heightOffset, radius, radius/2, 0.0f, startAngle, endAngle);
                graphicPath.closeSubPath();

                g.setColour(juce::Colour(50, 50, 50).withAlpha((0.5f/(i + 1) + 0.5f)));
                g.fillPath(graphicPath);
            }
        }
    }

    void drawRoundDial(juce::Graphics &g, float x, float y, float size, float position)
    {
        //==============================================================================

        float pi = juce::MathConstants<float>::pi;
        float dialStart = 1.25f * pi;
        float dialEnd = 2.75f * pi;
        float sliderPositionScaled = 2.0f + (1.0f - position);
        float dialPositionInRadians = dialStart + sliderPositionScaled * (dialEnd - dialStart);
        

        juce::Path dialBodyPath, dialDotPath, dialOutlinePath, dialSelectPath, tensionLeftPath, tensionRightPath;
        
        float dialOutlineRadius = (size * 0.8f)/2;
        float dialBodyRadius = (size * 0.7f)/2;
        float dialDotRadius = (size * 0.5f)/2;

        dialOutlinePath.addCentredArc(x + size/2, x + size/2,
                                      dialOutlineRadius, dialOutlineRadius,
                                      0.0f, dialStart, dialEnd, true);
        g.setColour(juce::Colour(200, 200, 200)); //

        juce::PathStrokeType strokeType(2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);
        g.strokePath(dialOutlinePath, juce::PathStrokeType(strokeType));

        //==============================================================================
        // dial body
        
        dialBodyPath.addCentredArc(x + size/2, y + size/2,
                                   dialBodyRadius, dialBodyRadius,
                                   0.0f, 0.0f, 6.28f, true);
        g.setColour(juce::Colour(200, 200, 200)); //
        g.fillPath(dialBodyPath);
        
        //==============================================================================
        // dial dot
        
        juce::Point<float> outlineCoords = {x + size/2 + std::sin(dialPositionInRadians) * dialDotRadius,
            x + size/2 + std::cos(dialPositionInRadians) * dialDotRadius};

        dialDotPath.addCentredArc(outlineCoords.x, outlineCoords.y,
                                  1.5, 1.5, 0.0f, 0.0f, pi * 2, true);
        
        g.setColour(juce::Colour(20, 20, 20)); //
        g.fillPath(dialDotPath);
    }
    
private:
    int index;
};
