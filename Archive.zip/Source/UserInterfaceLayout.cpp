/*
  ==============================================================================

    UserInterfaceLayout.cpp
    Created: 27 Jun 2025 1:15:03pm
    Author:  Takuma Matsui

  ==============================================================================
*/

#include "UserInterfaceLayout.h"
